#!/bin/sh

DIR=~/.gnome2/rhythmbox/
SOURCE_FILE=rhythmdb.xml
FILE="$DIR/$SOURCE_FILE"

test -d "$DIR" || mkdir -p "$DIR" || exit

if test -s "$FILE"
then
   BACKUP_FILE="$FILE.$(date +'%F')"
   mv -i "$FILE" "$BACKUP_FILE"
   echo "En backup av den existerande filen har gjorts och återfinns här: $BACKUP_FILE"
   echo
   echo "Lägger till de svenska internetradiokanalerna i den befintliga filen"
   sed '$d' "$BACKUP_FILE" > "$FILE"
   sed '1,2d' "$SOURCE_FILE" >> "$FILE"
else
   echo "Ingen fil hittades, kopierar..."
   echo
   cp "$SOURCE_FILE" "$FILE"
fi

echo "Nu ska allt vara klart."
echo
echo "Starta Rhythmbox och titta så allt ser okey ut."

if test -e "$BACKUP_FILE"
then
   echo "Skulle något vara fel tar du bort $FILE och döper om backuppen $BACKUP_FILE till samma namn."
   echo
   echo
fi
